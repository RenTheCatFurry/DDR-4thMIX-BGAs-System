local layer1 = {
    textures = {
        {
            img = "naok/a99_naok 4x3 (stretch).png",
            size = {80,80},
            frames = {8}
        }
    }
}

local layer2 = {
    textures = {
        {
            img = "naok/i99_naok f10 c04 8x8.png",
            size = {80,80},
            properties = {
                "colorama"
            }
        }
    },
    effect = "wagxout",
    effectlength = 2
}

return Def.ActorFrame{
    LoadActor("../_DDR_4thMIX_BGAs_System/layer.lua", layer1),
    LoadActor("../_DDR_4thMIX_BGAs_System/layer.lua", layer2)
}